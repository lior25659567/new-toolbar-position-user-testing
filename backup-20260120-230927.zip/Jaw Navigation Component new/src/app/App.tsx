import DentalWorkspace from '@/app/pages/DentalWorkspace';

export default function App() {
  return <DentalWorkspace />;
}
