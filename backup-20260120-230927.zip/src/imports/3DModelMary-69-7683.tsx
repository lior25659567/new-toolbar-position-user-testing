import imgScreenshot20240318At1457BackgroundRemoved from "figma:asset/367c137e30c1ba200ae84237f36257f31850fdaa.png";

export default function Component3DModelMary() {
  return (
    <div className="relative size-full" data-name="3D model - Mary">
      <div className="absolute inset-[14.06%_2.37%_14.12%_-2%]" data-name="Screenshot 2024-03-18 at 14.57 Background Removed">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src={imgScreenshot20240318At1457BackgroundRemoved} />
      </div>
    </div>
  );
}